<?php 
    echo '

    <p>

	    L\'utilisateur a bien été créée !

	    <br>

	    Veuillez activer votre compte via le lien reçu par mail. 

	    Vous allez être redirigé vers l\'accueil.


    </p>
    <meta http-equiv="refresh" content="3; URL=index.php" />';

?>