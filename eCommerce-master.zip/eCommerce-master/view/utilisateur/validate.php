<?php
    echo '<p> Votre mail a été validé vous pouvez désormais vous connecter sur votre espace client';
    echo '<a href="index.php?action=connect&controller=utilisateur"> Cliquez ici pour vous connecter des maintenant </a> </p>';
?>