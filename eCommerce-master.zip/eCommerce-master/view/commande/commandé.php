<h1>Commande validée</h1>

<a>Merci pour vos achats ! </a>
<a> Vous allez être redirigé vers la page produits pour de nouveaux achats ! </a>

 <meta http-equiv="refresh" content="5; URL=index.php" />

