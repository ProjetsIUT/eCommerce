<div class="div_center">
	<p>
		Le produit a été modifié avec succès.
		<br>
		Vous allez être redirigé vers la page des produits.
	</p>           
	<img class="logopage" src="./Images/logoananas.png">	<meta http-equiv="refresh" content="3; URL=index.php?action=readAll&controller=produit" />
</div>